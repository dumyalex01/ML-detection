from PyQt5 import uic
from PyQt5.QtWidgets import *
import settingButtons as sb
import networkAnalyseFunctions as naf

def cleanFrame(myframe):

    for child in myframe.findChildren(QWidget):
        child.hide()

def hideButtons(window):
    
    window.ModificaDate.hide()
    window.PermiteAcces.hide()
    window.UtilizatorNou.hide()
    window.JurnalConexiuni.hide()
    window.StergeUtilizator.hide()
    window.SettingFrame.hide()

def showButtons(window):

    window.ModificaDate.show()
    window.PermiteAcces.show()
    window.UtilizatorNou.show()
    window.JurnalConexiuni.show()
    window.StergeUtilizator.show()
    window.SettingFrame.show()

def getButtons(window):

    window.ModificaDate=window.findChild(QPushButton,"ModificaDate")
    window.PermiteAcces=window.findChild(QPushButton,"PermiteAcces")
    window.UtilizatorNou=window.findChild(QPushButton,"UtilizatorNou")
    window.JurnalConexiuni=window.findChild(QPushButton,"JurnalConexiuni")
    window.StergeUtilizator=window.findChild(QPushButton,"StergeUtilizator")

    window.SettingFrame=window.findChild(QFrame,"SettingFrame")

# Afiseaza ce trebuie la setari pentru root
def settings(window):


    cleanFrame(window.myFrame)

    getButtons(window)
    showButtons(window)

    
    window.myFrame.show()

    

    window.PermiteAcces.clicked.connect(lambda: sb.createContentPermiteAcces(window.SettingFrame))
    window.ModificaDate.clicked.connect(lambda: sb.createContentModificaDate(window.SettingFrame))
    window.UtilizatorNou.clicked.connect(lambda: sb.createContentUtilizatorNou(window.SettingFrame))
    window.StergeUtilizator.clicked.connect(lambda: sb.createContentStergeUtilizator(window.SettingFrame))
    window.JurnalConexiuni.clicked.connect(lambda: sb.openLogWindow(window))

   


#Afiseaza ce trebuie la setari pentru user simplu
def settingsUser(window):

    getButtons(window)
    hideButtons(window)

    window.myFrame.show()




def networkAnalyse(window):

    window.myFrame.show()
    cleanFrame(window.myFrame)

    hideButtons(window)

    naf.showInterface(window.myFrame)
    
    
