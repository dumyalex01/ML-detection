
import sys
from PyQt5 import uic
from PyQt5.QtWidgets import *
import utils as u
import buttonsFunction as bf
import setup
import socketUtils as su
import protocols as p


class LogsWindow(QMainWindow):
    def __init__(self):
        super(LogsWindow, self).__init__()
        uic.loadUi("Logs.ui", self)
        self.comboTip=self.findChild(QComboBox,"comboTip")
        self.comboValoare=self.findChild(QComboBox,"comboValoare")
        self.ButonFiltrare=self.findChild(QPushButton,"ButonFiltrare")
        self.content=self.findChild(QPlainTextEdit,"content")
            
        self.comboTip.addItems(["Actiune","Mac","Utilizator"])
        self.comboValoare.addItems(["Stergere", "Adaugare", "Login", "Logout", "Modificare_date"])

        self.getLogs()
           

        self.comboTip.currentIndexChanged.connect(self.on_combo_change)
        self.ButonFiltrare.clicked.connect(self.executeFilter)

    
    def on_combo_change(self):

        selected_text = self.comboTip.currentText()
        self.comboValoare.clear()

        if selected_text == "Actiune":
            self.comboValoare.addItems(["Stergere", "Adaugare", "Login", "Logout", "Modificare_date"])
        if selected_text == "Utilizator":
            message = p.PROTOCOL_GET_UTILIZATORI
            users = su.sendMessage(message)
            users = users.split("\n")
            for user in users:
                self.comboValoare.addItem(user)
        if selected_text == "Mac":
            message = p.PROTOCOL_GET_MAC
            macs = su.sendMessage(message)
            macs = macs.split("\n")
            for mac in macs:
                self.comboValoare.addItem(mac)
    
    def getLogs(self):

        message = p.PROTOCOL_LOG_CONEXIUNI
        returnMessage = su.sendMessage(message)

        msg = returnMessage.split("\n")
        for line in msg:
            line_modified = "\t\t" + line + "\n"
            self.content.insertPlainText(line_modified)
    
    def executeFilter(self):
        
        self.content.clear()
        message=p.PROTOCOL_GET_LOGURI_FILTRATE + " " + self.comboTip.currentText() + " " + self.comboValoare.currentText()
        returnMessage=su.sendMessage(message)
        
        msg = returnMessage.split("\n")

        for line in msg:
            line_modified = "\t\t" + line + "\n"
            self.content.insertPlainText(line_modified)
            




            