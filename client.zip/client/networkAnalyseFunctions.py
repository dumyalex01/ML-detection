import sys
from PyQt5 import uic
from PyQt5.QtWidgets import *
import utils as u
import buttonsFunction as bf
import setup
from LogsWindow import *
import threading
import os
import time
from PyQt5.QtGui import *

barrier=threading.Barrier(2)

def obtainIP(ip, label, textArea):

    shadow = QGraphicsDropShadowEffect()
    shadow.setBlurRadius(10) 
    shadow.setOffset(0, 0)   

    while True:
        response = os.system(f"ping -c 1 {ip}")
        print(f"Am executat print si raspunsul este {response}")
        
        if response == 0:
            label.setStyleSheet("background-color:green")
            textArea.insertPlainText(f"Cod conexiune {response} - Conexiune reusita la {ip}\n")
            shadow.setColor(QColor(0, 255, 0))
        else:
            label.setStyleSheet("background-color:red")
            textArea.insertPlainText(f"Cod conexiune {response} - Conexiune esuata la {ip}\n")
            shadow.setColor(QColor(255, 0, 0))

        label.setGraphicsEffect(shadow)        


        time.sleep(10)
        
        textArea.clear()
        


def CreateCheckBox(name,text,window,value):
        
        newCheck = QCheckBox(text , window)
        newCheck.setObjectName(name)
        newCheck.setGeometry(30,value,200,30)
        newCheck.setStyleSheet("font-weight:bold;font-family:italic;font-size:16px;")
        newCheck.show()



def showInterface(window):

    labelStatusServer = QLabel(window)
    labelStatusServer.setGeometry(30,20,10,10)
    labelStatusServer.setStyleSheet("background-color:green")

    labelServer = QLabel("Server",window)
    labelServer.setGeometry(50,20,50,10)
    labelServer.setStyleSheet("font-size:12px")

    labelStatusSandbox = QLabel(window)
    labelStatusSandbox.setGeometry(30,40,10,10)
    labelStatusSandbox.setStyleSheet("background-color:green")

    labelSandbox = QLabel("Sandbox",window)
    labelSandbox.setGeometry(50,40,60,10)
    labelSandbox.setStyleSheet("font-size:12px")

    frameMessageConnection = QFrame(window)
    frameMessageConnection.setGeometry(250,0,900,60)
    frameMessageConnection.setStyleSheet("background-color:black")
    textArea= QPlainTextEdit(frameMessageConnection)
    textArea.setGeometry(0,0,800,55)
    textArea.setStyleSheet("font-size:18px;font-weight:bold;font-family:italic;color:white")
    textArea.setReadOnly(True)

    labelChangeTimer = QLabel("Seteaza intervalul de timp",window)
    labelChangeTimer.setGeometry(30,80,250,30)
    labelChangeTimer.setStyleSheet("font-size:14px;font-weight:bold;font-style:italic;")

    TimeComboBox= QComboBox(window)
    TimeComboBox.setGeometry(30,120,200,30)
    TimeComboBox.addItems(["60s","90s","120s","150s","180s","210s","240s"])
    TimeComboBox.setStyleSheet("font-size:14px;color:lightgreen;font-weight:bold;font-family:italic;background-color:black")

    labelSelectPacket = QLabel("Alege tipurile de pachete:",window)
    labelSelectPacket.setGeometry(30,170,230,30)
    labelSelectPacket.setStyleSheet("font-size:16px;color:lightgreen;font-weight:bold;font-family:italic;background-color:black")

    value=200
    CreateCheckBox("TCP","TCP",window,value)
    CreateCheckBox("IP","IP",window,value+30)
    CreateCheckBox("ICMP","ICMP",window,value+60)
    CreateCheckBox("UDP","UDP",window,value+90)
    CreateCheckBox("HTTP","HTTP",window,value+120)
    CreateCheckBox("ARP","ARP",window,value+150)
    CreateCheckBox("HTTPS","HTTPS",window,value+180)




    frameMessageConnection.show()
    labelSelectPacket.show()
    labelStatusServer.show()
    labelServer.show()
    labelStatusSandbox.show()
    labelSandbox.show()
    labelChangeTimer.show()
    TimeComboBox.show()

    threading.Thread(target=obtainIP,args=("8.3.26.2500",labelStatusServer,textArea),daemon=True).start()
    threading.Thread(target=obtainIP,args=("127.0.0.1",labelStatusSandbox,textArea),daemon=True).start()

    
