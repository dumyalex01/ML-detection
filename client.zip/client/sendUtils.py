import socket

def sendMessage(message):

    host=socket.gethostname()
    port=8887

    client_socket=socket.socket()
    client_socket.connect((host,port))

    client_socket.send(message.encode())
    
    receivedMessage=client_socket.recv(100000).decode()
    
    return receivedMessage



    
