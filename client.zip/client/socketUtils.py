import socket

def sendMessage(message):

    host=socket.gethostname()
    port=8887

    client_socket=socket.socket()
    client_socket.connect((host,port))

    client_socket.send(message.encode())
    
    receivedMessage=client_socket.recv(100000).decode()
    
    return receivedMessage

def sendFile(file_path):
    
    host=socket.gethostname()
    port=8888

    client_socket=socket.socket()
    client_socket.connect((host,port))

    file=open(file_path,"rb")


    while True:

        data=file.read(1024)
        
        if not data:
            break

        client_socket.sendall(data)
        print("Trimis " + str(len(data)) + str(data))


    
