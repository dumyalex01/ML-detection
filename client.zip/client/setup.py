import subprocess
import utils as u
import protocols as p
import socketUtils as su


def startSetup():

    print("Aplicatia nu are inca setup-ul facut!")
    print("Va rugam introduceti numele grupului de utilizatori:")
    name=input()

    result = subprocess.run(['./bashScript/setup.sh', name], capture_output=True, text=True)
    

def executeSetup():
    
    file=open("setupExecuted","rt")
    line=file.readline()
    if line=="0":
        startSetup()
    subprocess.run(['./bashScript/install.sh'])

    name = u.getCurrentUser()
    mac = u.getCurrentMac()

    message = p.PROTOCOL_ADAUGARE_ACTIUNE_LOGIN + " " + name + " " + mac

    su.sendMessage(message)
    
    
    