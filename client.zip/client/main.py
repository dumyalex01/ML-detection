import sys
from PyQt5 import uic
from PyQt5.QtWidgets import *
import utils as u
import buttonsFunction as bf
import setup
from LogsWindow import *
import threading


class MainWindow(QMainWindow):

    def __init__(self):
        
        super(MainWindow, self).__init__()
        uic.loadUi("interfata.ui", self)

        self.myFrame=self.findChild(QFrame,"frameContent")
        self.myFrame.hide()
        self.log_window=None

        self.initializeButtons()
    

    def initializeButtons(self):

        self.buttonSettings=self.findChild(QPushButton,"Setari")
        self.buttonFileAnalyse=self.findChild(QPushButton,"AnalizaFisiere")
        self.buttonNetworkAnalyse=self.findChild(QPushButton,"AnalizaRetea")
        self.buttonPhishingAnalyse=self.findChild(QPushButton,"AnalizaPhising")
        self.buttonLogs=self.findChild(QPushButton,"Loguri")
        self.buttonHistory=self.findChild(QPushButton,"Istoric")
        self.buttonHelp=self.findChild(QPushButton,"Ajutor")

        self.organizeButtonsFunctions()

    def organizeButtonsFunctions(self):

        if u.getCurrentUser()== 'root':
            self.buttonSettings.clicked.connect(lambda: bf.settings(self))
        else:
            self.buttonSettings.clicked.connect(lambda: bf.settingsUser(self))
        self.buttonNetworkAnalyse.clicked.connect(lambda: bf.networkAnalyse(self))
        
        

        
if __name__ == "__main__":

    setup.executeSetup()
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())