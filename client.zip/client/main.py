import sys
from PyQt5 import uic
from PyQt5.QtWidgets import *
import utils as u
import buttonsFunction as bf
import setup
from LogsWindow import *
import threading

class MainWindow(QMainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()
        uic.loadUi("interfata.ui", self)

        self.myFrame = self.findChild(QFrame, "frameContent")
        self.myFrame.hide()
        self.log_window = None

        self.initializeButtons()

    def initializeButtons(self):
        self.buttonSettings = self.findChild(QPushButton, "Setari")
        self.buttonFileAnalyse = self.findChild(QPushButton, "AnalizaFisiere")
        self.buttonNetworkAnalyse = self.findChild(QPushButton, "AnalizaRetea")
        self.buttonPhishingAnalyse = self.findChild(QPushButton, "AnalizaPhising")
        self.buttonLogs = self.findChild(QPushButton, "Loguri")
        self.buttonHistory = self.findChild(QPushButton, "Istoric")
        self.buttonHelp = self.findChild(QPushButton, "Ajutor")

        self.organizeButtonsFunctions()

    def organizeButtonsFunctions(self):
        if u.getCurrentUser() == 'root':
            self.buttonSettings.clicked.connect(lambda: bf.settings(self))
        else:
            self.buttonSettings.clicked.connect(lambda: bf.settingsUser(self))
        self.buttonNetworkAnalyse.clicked.connect(lambda: bf.networkAnalyse(self))


    def closeEvent(self, event):

        reply = QMessageBox(self)
        reply.setWindowTitle('Confirmare')
        reply.setText("Sigur vrei să inchizi aplicatia?")
        reply.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        reply.setDefaultButton(QMessageBox.No)

        reply.setStyleSheet("""
            QMessageBox {
                background: transparent;
                background-color:white;
            }
            QLabel {
                background:transparent;
                background-color: white;
                color: black;
            }
            QPushButton {
                background:transparent;
                background-color:black;
                            
            }
        """)

        reply_result = reply.exec_()

        if reply_result == QMessageBox.Yes:
            message = p.PROTOCOL_ADAUGARE_ACTIUNE_LOGOUT + " " + u.getCurrentUser() + " " + u.getCurrentMac()
            su.sendMessage(message)
            event.accept()
        else:
            event.ignore()


if __name__ == "__main__":
    setup.executeSetup()
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
