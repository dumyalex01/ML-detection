import subprocess
import sys
from PyQt5 import uic
from PyQt5.QtWidgets import *
import utils as u
from PyQt5.QtCore import Qt
import protocols as p
import sendUtils as su

def getCurrentUser():
    name_result = subprocess.run(['whoami'], capture_output=True, text=True)
    name = name_result.stdout.strip()
    return name

def getCurrentMac():
    mac_result = subprocess.run(['./bashScript/macadress.sh'], capture_output=True, text=True)
    mac = mac_result.stdout.strip()
    return mac

def showMessageBox(title,content):
    msg_box = QMessageBox()
    msg_box.setWindowTitle(title)
    msg_box.setText(content)
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)

    msg_box.exec_()

def getGroup():

    file=open("setupExecuted","rt")
    group=file.readline()
    group=group[:-1]
    return group