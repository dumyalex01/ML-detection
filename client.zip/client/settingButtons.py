import sys
from PyQt5 import uic
from PyQt5.QtWidgets import *
import utils as u
from PyQt5.QtCore import Qt
import subprocess
import protocols as p
import sendUtils as su
from PyQt5.QtGui import *
import re
from LogsWindow import *


def clean(frame):

    for child in frame.findChildren(QWidget):
        child.hide()

def addUserOnServer(comboBox,group):

    name=comboBox.currentText()

    message = p.PROTOCOL_ADAUGARE_ACTIUNE_AUTENTIFICARE + " " + name + " " + u.getCurrentMac()
    su.sendMessage(message)
    subprocess.run(["sudo","usermod","-aG",group,name])

    u.showMessageBox("Adaugare reusita!","Utilizatorul a primit acces cu succes!")


def createContentPermiteAcces(frame):

    clean(frame)

    labelInfo= QLabel("Puteti oferi acces unui utilizator deja existent in sistem",frame)
    labelInfo.setGeometry(100,70,551,81)
    labelInfo.setStyleSheet("font-size:20px")

    labelChoose=QLabel("Alegeti utilizatorul",frame)
    labelChoose.setGeometry(210,210,181,41)
    labelChoose.setStyleSheet("font-size:20px")

    comboBox=QComboBox(frame)

    comboBox.setGeometry(210,260,221,41)
    comboBox.setStyleSheet("font-size:18px;background-color:white")

    myGroupFile=open("setupExecuted","r+")
    group=myGroupFile.read()
    group=group[:-1]
    result = subprocess.run(['./bashScript/users.sh',group], capture_output=True, text=True)
    
    output=result.stdout.split()
    for option in output:
        comboBox.addItem(option)


    buttonSend=QPushButton("Modifica",frame)
    buttonSend.setGeometry(390,450,191,51)
    buttonSend.setStyleSheet("font-size:16px;background-color:white")

    buttonSend.clicked.connect(lambda: addUserOnServer(comboBox,group))

    buttonSend.show()
    labelInfo.show()
    labelChoose.show()
    comboBox.show()

def validatePhone(phone):
     phone_regex=r'^[0-9]{10}$'

     if re.match(phone_regex,phone):
          return True
     else:
          return False
     
def validateMail(mail):

    email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    
    
    if re.match(email_regex, mail):
        return True
    else:
        return False

def sendMailAndPhoneToServer(phoneInput,mailInput):

    phone=phoneInput.toPlainText()
    mail=mailInput.toPlainText()
    if validateMail(mail) == True and validatePhone(phone)==True:
           u.showMessageBox("OK","Datele au fost trimise cu succes!")
           su.sendMessage(p.PROTOCOL_EMAIL+ " " + u.getCurrentUser() + " " + u.getCurrentMac() + " " + mail + " "+phone)
           #todo Functionalitate notificare
    else:
           u.ShowMessageBox("Eroare","Format incorect la mail sau la numar telefon!")


def createContentModificaDate(frame):

    clean(frame)

    labelTitle=QLabel("Modificare Date",frame)
    labelTitle.setGeometry(250,30,501,81)
    labelTitle.setStyleSheet("font-size:25px")

    labelContent=QPlainTextEdit("   Puteti modifica datele de contact pentru a primi notificari referitoare la actiuni malitioase efectuate asupra statiei dumneavoastra",frame)
    labelContent.setGeometry(100,130,501,101)
    labelContent.setStyleSheet("font-size:20px")
    
    labelImage = QLabel(frame)
    pixmap1 = QPixmap("/home/alex/Desktop/Licenta2/client/call.png")
    scaled_pixmap1 = pixmap1.scaled(51, 51) 
    labelImage.setPixmap(scaled_pixmap1)
    labelImage.setGeometry(100, 270, 51, 51)

    labelImage2 = QLabel(frame)
    pixmap2 = QPixmap("/home/alex/Desktop/Licenta2/client/gmail.png")
    scaled_pixmap2 = pixmap2.scaled(51, 51) 
    labelImage2.setPixmap(scaled_pixmap2)
    labelImage2.setGeometry(100, 380, 51, 51)

    phoneInput=QTextEdit(frame)
    phoneInput.setGeometry(180,270,351,51)
    phoneInput.setStyleSheet("font-size:16px;background:transparent;background-color:white")

    mailInput=QTextEdit(frame)
    mailInput.setGeometry(180,380,351,51)
    mailInput.setStyleSheet("font-size:16px;background-color:white")

    button=QPushButton("Trimite",frame)
    button.setGeometry(240,470,181,41)
    button.setStyleSheet("font-size:16px;background-color:white")
    button.clicked.connect(lambda: sendMailAndPhoneToServer(phoneInput,mailInput))


    labelImage.show()
    labelImage2.show()
    labelContent.show()
    labelTitle.show()
    phoneInput.show()
    mailInput.show()
    button.show()

def sendUserToServer(inputText,password_input):
    
    name=inputText.toPlainText()
    password=password_input.text()
    
      

    message = p.PROTOCOL_ADAUGARE_ACTIUNE_AUTENTIFICARE + " " + name + " " + u.getCurrentMac()
    su.sendMessage(message)

    result=subprocess.run(["./bashScript/addnewuser.sh",name,password,u.getGroup()])
    u.showMessageBox("Succes","User-ul a fost adaugat cu succes!")

def createContentUtilizatorNou(frame):
     
     clean(frame)

     label=QLabel("Adauga un utilizator nou",frame)
     label.setGeometry(200,30,481,81)
     label.setStyleSheet("font-size:30px")

     labelDescription=QLabel("Utilizatorul va fi adaugat direct in grupul care are acces la aplicatie",frame)
     labelDescription.setGeometry(50,150,601,51)
     labelDescription.setStyleSheet("font-size:20px")

     labelImage = QLabel(frame)
     pixmap1 = QPixmap("/home/alex/Desktop/Licenta2/client/profile.png")
     scaled_pixmap1 = pixmap1.scaled(51, 51) 
     labelImage.setPixmap(scaled_pixmap1)
     labelImage.setGeometry(100, 270, 51, 51)

     labelImage2 = QLabel(frame)
     pixmap2 = QPixmap("/home/alex/Desktop/Licenta2/client/reset-password.png")
     scaled_pixmap2 = pixmap2.scaled(51, 51) 
     labelImage2.setPixmap(scaled_pixmap2)
     labelImage2.setGeometry(100, 360, 51, 51)

     inputText=QTextEdit(frame)
     inputText.setGeometry(160,270,401,51)
     inputText.setStyleSheet("font-size:20px;background-color:white")

     password_input = QLineEdit(frame)
     password_input.setPlaceholderText("Introdu parola")
     password_input.setEchoMode(QLineEdit.Password) 
     password_input.setGeometry(160,360,401,51)
     password_input.setStyleSheet("background-color:white;font-size:20px")

     button=QPushButton("Adauga",frame)
     button.setGeometry(260,500,201,40)
     button.setStyleSheet("background-color:white;font-size:16px")
     button.clicked.connect(lambda: sendUserToServer(inputText,password_input))
     
     labelImage.show()
     labelImage2.show()
     inputText.show()
     labelDescription.show()
     label.show()
     button.show()
     password_input.show()

def deleteUserOnServer(comboBox):
     
     name=comboBox.currentText()

     message=p.PROTOCOL_ADAUGARE_ACTIUNE_STERGERE + " " + name + " " + u.getCurrentMac()
     su.sendMessage(message)

     subprocess.run(["sudo","gpasswd","-d",name,u.getGroup()])
     u.showMessageBox("OK","Utilizatorul a fost sters cu succes!")

def createContentStergeUtilizator(frame):
     
    clean(frame)

    labelInfo= QLabel("Puteti opri accesul unui utilizator",frame)
    labelInfo.setGeometry(100,70,551,81)
    labelInfo.setStyleSheet("font-size:20px")

    labelChoose=QLabel("Alegeti utilizatorul",frame)
    labelChoose.setGeometry(210,210,181,41)
    labelChoose.setStyleSheet("font-size:20px")

    comboBox=QComboBox(frame)

    comboBox.setGeometry(210,260,221,41)
    comboBox.setStyleSheet("font-size:18px;background-color:white")

    myGroupFile=open("setupExecuted","r+")
    group=myGroupFile.read()
    group=group[:-1]
    result = subprocess.run(['./bashScript/groupusers.sh',group], capture_output=True, text=True)
    
    output=result.stdout.split()
    for option in output:
        comboBox.addItem(option)


    buttonSend=QPushButton("Sterge",frame)
    buttonSend.setGeometry(390,450,191,51)
    buttonSend.setStyleSheet("font-size:16px;background-color:white")

    buttonSend.clicked.connect(lambda: deleteUserOnServer(comboBox))

    buttonSend.show()
    labelInfo.show()
    labelChoose.show()
    comboBox.show()


def openLogWindow(window):
    
    print("Opening LogsWindow...")
    window.log_window = LogsWindow() 
    window.log_window.show()

   

    

   