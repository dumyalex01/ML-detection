#!/bin/bash

username=$1
password=$2
group=$3

sudo useradd -m -s /bin/bash -G "$group" "$username"

echo "$username:$password" | sudo chpasswd

if id "$username" &>/dev/null; then
    echo "User '$username' created successfully and added to group '$group'."
else
    echo "Failed to create user '$username'."
    exit 3
fi