#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 groupName"
    exit 1
fi

groupName=$1

value=$(grep "^$groupName:" /etc/group)
groupUsers=$(echo "$value" | cut -d ":" -f4)

allUsers=$(awk -F: '$3 >= 1000 {print $1}' /etc/passwd)

for user in $allUsers; do
    if ! echo "$groupUsers" | grep -qw "$user"; then
        echo "$user"
    fi
done
