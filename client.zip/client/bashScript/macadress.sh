#!/bin/bash

ip link show | egrep "link/ether*." | tr " " "-" | cut -d"-" -f6