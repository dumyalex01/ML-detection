#!/bin/bash

export DISPLAY=:0
echo $DISPLAY
xhost +local: