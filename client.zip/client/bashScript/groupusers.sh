#!/bin/bash

group=$1
value=`cat /etc/group | grep $1 | cut -d ":" -f4 | tr "," " "`
echo $value