#!/bin/bash

echo Grupul creat va avea numele $1

sudo groupadd $1

echo Se schimba permisiunile aplicatiei...

chmod 770 main.py
sudo chgrp $1 main.py
sudo chown root main.py

sudo echo $1 > setupExecuted