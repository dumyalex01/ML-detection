import socket
import protocols as protocols
import connector as connector
import actions as actions
import threading

def getProtocol(message):

    protocol=message.split()
    return protocol[0]

def runAction(client_socket,message,cursor,connection):

    protocol=getProtocol(message)
    print(message)
    if protocol == protocols.PROTOCOL_ADAUGARE_ACTIUNE_LOGIN:
        return actions.adaugareActiune(message,cursor,connection,'Login')
    if protocol == protocols.PROTOCOL_ADAUGARE_ACTIUNE_LOGOUT:
        return actions.adaugareActiune(message,cursor,connection,'Logout')
    if protocol == protocols.PROTOCOL_ADAUGARE_ACTIUNE_AUTENTIFICARE:
        return actions.adaugaUtilizator(message,cursor,connection,'Autentificare')
    if protocol == protocols.PROTOCOL_ADAUGARE_ACTIUNE_STERGERE:
        return actions.removeUtilizator(message,cursor,connection,'Stergere')
    if protocol == protocols.PROTOCOL_LOG_CONEXIUNI:
        return actions.getLogConexiuni(cursor,connection)
    if protocol == protocols.PROTOCOL_EMAIL:
        return actions.insertUsersData(connection,cursor,message)
    if protocol ==protocols.PROTOCOL_AFISARE_UTILIZATORI_MAC:
        return actions.getUsersByMac(connection,cursor,message)
    if protocol==protocols.PROTOCOL_AFISARE_LOGURI_UTILIZATOR_CURENT:
        return actions.getUsersLogs(cursor,connection,message)
    if protocol==protocols.PROTOCOL_GET_UTILIZATORI:
        return actions.getUsers(cursor,connection)
    if protocol==protocols.PROTOCOL_GET_MAC:
        return actions.getMacs(cursor,connection)
    if protocol==protocols.PROTOCOL_GET_LOGURI_FILTRATE:
        return actions.filteredLogs(cursor,connection,message)
    
    actions.constructFile(message)
    return "OK"
    
    
        


def handle_command(client_socket, cursor, connection):
    while True:
        message = client_socket.recv(10000).decode()
        if not message:
            break

        messageToSend = runAction(client_socket, message, cursor, connection)
        client_socket.send(messageToSend.encode())

def handle_file(file_server_socket):
    while True:
        client_socket, address = file_server_socket.accept()
        print(f"S-a realizat o conexiune pentru fisier de la adresa {address}")

        file_data = b""
        while True:
            data = client_socket.recv(1024)
            print("S-a primit " + str(data))
            if not data or data == b"EOF":
                break
            file_data += data

        print("In final voi scrie " + str(file_data))
        with open("received_file", "wb") as file:
            file.write(file_data)
        print("Fisierul a fost primit si salvat.")

        client_socket.close()

def run():
    host = socket.gethostname()
    command_port = 8887
    file_port = 8888

    server_socket = socket.socket()
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((host, command_port))
    server_socket.listen(5)

    file_server_socket = socket.socket()
    file_server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    file_server_socket.bind((host, file_port))
    file_server_socket.listen(5)

    print(f"Serverul asteapta conexiuni pe portul {command_port} pentru comenzi")
    print(f"Serverul asteapta conexiuni pe portul {file_port} pentru fișiere")

    connexion, cursor = connector.create_connection()

    threading.Thread(target=handle_file, args=(file_server_socket,)).start()

    while True:
        client_socket, address = server_socket.accept()
        print(f"S-a realizat o conexiune de la adresa {address}")
        threading.Thread(target=handle_command, args=(client_socket, cursor, connexion)).start()

if __name__ == '__main__':
    run()
