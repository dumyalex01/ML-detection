
import socket

def adaugareActiune(message,cursor,connection,actiune):
        print("Se executa actiunea " + actiune)
        msg=message.split()

        name=msg[1]
        mac=msg[2]

        query="SELECT ID from Utilizatori WHERE Nume=%s and MAC=%s"

        cursor.execute(query,(name,mac))
        
        ID=cursor.fetchone()
        
        query="""INSERT INTO Actiuni(ID_User,Tip_Actiune,Timestamp)
        values(%s,%s,NOW())"""

        cursor.execute(query,(ID[0],actiune))

        connection.commit()
        print("S-a adaugat la baza de date!")

        return "OK"

def adaugaUtilizator(message,cursor,connection,actiune):
        
        msg=message.split()

        name=msg[1]
        mac=msg[2]

        query_preliminar="SELECT* from Utilizatori WHERE Nume=%s and Mac=%s"

        cursor.execute(query_preliminar,(name,mac))

        result=cursor.fetchone()

        if result is None:

            query="INSERT INTO Utilizatori(Nume,Mac,Email,Telefon,Status) values(%s,%s,NULL,NULL,'On')"

            cursor.execute(query,(name,mac))

        else:
            
            query="UPDATE Utilizatori SET Status='On' WHERE Nume=%s and Mac=%s"

            cursor.execute(query,(name,mac))

        connection.commit()

        adaugareActiune(message,cursor,connection,actiune)
        
        return "OK"

def removeUtilizator(message,cursor,connection,actiune):
        
        msg=message.split()
        name=msg[1]
        mac=msg[2]
        
        query="SELECT ID from Utilizatori Where Nume=%s and Mac=%s"

        cursor.execute(query,(name,mac))

        ID=cursor.fetchone()

        adaugareActiune(message,cursor,connection,actiune)

        query2="UPDATE Utilizatori SET Status='OFF' WHERE ID=%s"

        cursor.execute(query2,(ID[0],))

        return "OK"

def getLogConexiuni(cursor,connection):
      
      query="""SELECT u.Nume,u.Mac,a.Tip_Actiune,a.Timestamp FROM Utilizatori u inner join Actiuni a
               on a.ID_User=u.ID"""
      cursor.execute(query)

      result=cursor.fetchall()
      
      messageToSend=""

      for i in range(len(result)):
            messageToSend = messageToSend + result[i][0] + " " + result[i][1] + " " + result[i][2] + " " + result[i][3].strftime("%Y-%m-%d %H:%M:%S")
            messageToSend = messageToSend + "\n"
      
      return messageToSend

def insertUsersData(connection,cursor,message):
      
    messageSplited=message.split()

    name=messageSplited[1]
    mac=messageSplited[2]
    email=messageSplited[3]
    phone=messageSplited[4]

    query="""UPDATE Utilizatori SET Email=%s,Telefon=%s WHERE Nume=%s AND Mac=%s"""

    cursor.execute(query,(email,phone,name,mac,))

    query="SELECT ID from Utilizatori WHERE Nume=%s and MAC=%s"

    cursor.execute(query,(name,mac))
        
    ID=cursor.fetchone()
        
    query="""INSERT INTO Actiuni(ID_User,Tip_Actiune,Timestamp)
    values(%s,%s,NOW())"""

    cursor.execute(query,(ID[0],'Modificare_date'))

    connection.commit()


    return "OK"

def getUsersByMac(connection,cursor,message):
      
      messageSplited=message.split()

      mac=messageSplited[1]

      query="SELECT Nume,Status from Utilizatori where Mac=%s"

      cursor.execute(query,(mac,))

      result=cursor.fetchall()

      messageToSend=""

      for i in range(len(result)):
            messageToSend=messageToSend+result[i][0] + " " + result[i][1]
            messageToSend=messageToSend + "\n"

      connection.commit()

      return messageToSend

def getUsersLogs(cursor,connection,message):
      
      messageSplited=message.split()

      user = messageSplited[1]
      mac  = messageSplited[2]

      query="""SELECT u.Nume,u.Mac,a.Tip_Actiune,a.Timestamp FROM Utilizatori u inner join Actiuni a
               on a.ID_User=u.ID WHERE u.Nume=%s and u.Mac=%s"""
      
      cursor.execute(query,(user,mac,))

      result=cursor.fetchall()

      connection.commit()
      
      messageToSend=""

      for i in range(len(result)):
            messageToSend = messageToSend + result[i][0] + " " + result[i][1] + " " + result[i][2] + " " + result[i][3].strftime("%Y-%m-%d %H:%M:%S")
            messageToSend = messageToSend + "\n"
      
      return messageToSend

def getUsers(cursor,connection):
      
      query="SELECT Nume from Utilizatori"

      cursor.execute(query)

      result=cursor.fetchall()

      connection.commit()

      messageToSend=""
      for i in range(len(result)):
            messageToSend=messageToSend + result[i][0] +"\n"
      print(messageToSend)
      return messageToSend

def getMacs(cursor,connection):
      
      query="SELECT DISTINCT Mac from Utilizatori"

      cursor.execute(query)

      result=cursor.fetchall()

      connection.commit()

      messageToSend=""
      for i in range(len(result)):
            messageToSend=messageToSend + result[i][0]+"\n"

      return messageToSend

def filteredLogs(cursor,connection,message):

      message=message.split()

      tip=message[1]
      value=message[2]
      messageToSend="OK"

      if tip=="Utilizator":
            query="""SELECT u.Nume,u.Mac,a.Tip_Actiune,a.Timestamp FROM Utilizatori u inner join Actiuni a
               on a.ID_User=u.ID WHERE u.Nume=%s"""
      if tip=="Actiune":
            query="""SELECT u.Nume,u.Mac,a.Tip_Actiune,a.Timestamp FROM Utilizatori u inner join Actiuni a
               on a.ID_User=u.ID WHERE a.Tip_Actiune=%s """
      if tip=="Mac":
            query="""SELECT u.Nume,u.Mac,a.Tip_Actiune,a.Timestamp FROM Utilizatori u inner join Actiuni a
               on a.ID_User=u.ID WHERE u.Mac=%s"""
      
      cursor.execute(query,(value,))

      result=cursor.fetchall()
      
      connection.commit()
      
      messageToSend=""
      if len(result)>0:
            for i in range(len(result)):
                  messageToSend = messageToSend + result[i][0] + " " + result[i][1] + " " + result[i][2] + " " + result[i][3].strftime("%Y-%m-%d %H:%M:%S")
                  messageToSend = messageToSend + "\n"
      
      else:
            messageToSend=" "

      return messageToSend

def constructFile(message,file_path):
    
    file=open(file_path, "b+a")

    file.write(message.encode())
    
    print(f"Fișierul a fost primit și salvat ca {file_path}")
    
