import mysql.connector

def create_connection():
    
    connection=None
    connection=mysql.connector.connect(
        host='localhost',
        user='alex',
        password='Alexandrunir359.',
        database='Utilizatori'
    )

    if connection.is_connected():
        print("Conexiune la baza de date reusita!")

    cursor=connection.cursor()

    if cursor is not None:
        print("Cursor creat cu succes!")
    
    return connection,cursor

def close_connection(cursor,connection):

    if cursor is not None:
        cursor.close()
    if connection is not None:
        connection.close()
    print("Conexiune la baza de date inchisa!")
